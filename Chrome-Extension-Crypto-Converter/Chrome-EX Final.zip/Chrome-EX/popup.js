/**
 * Wallet popup UI
 *
 * This script handles:
 * - Getting and displaying portfolio data
 * - Adding and removing crypto amounts
 * - Drawing the pie chart
 * - Storing user preferences (last selected symbol)
 */


// ==== Constant variables for DOM elements ====
const $symbol     = document.getElementById('symbol');
const $amountInp  = document.getElementById('amount');
const $addBtn     = document.getElementById('addBtn');
const $removeBtn  = document.getElementById('removeBtn');
const $grandTotal = document.getElementById('grandTotal');
const $body       = document.getElementById('walletBody');
const $chartCvs   = document.getElementById('pieChart');

// ===== Brand colours for coins (used in table + chart) =====
const COLORS = {
    BTC: '#4e79a7',
    ETH: '#f28e2b',
    LTC: '#e15759',
    ADA: '#d2c917',
    XRP: '#59a14f'
};

// Chart.js instance (used so we can update/destroy the chart later)
let chart;

/**
 * Returns base chart size based on how many rows we have.
 * This keeps the chart fitting nicely in the popup.
 */
function chartBaseSize (rows) {
    if (rows <= 2) return 260;
    if (rows === 3) return 220;
    if (rows === 4) return 170;
    if (rows === 5) return 120;
    return 100;
}

/**
 * Convert HEX color to RGBA format with optional transparency.
 * @param {string} hex - The HEX color code.
 * @param {number} alpha - Opacity value (0 to 1).
 */
function hexToRgba (hex, alpha = 1) {
    const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!m) return hex;
    const r = parseInt(m[1], 16);
    const g = parseInt(m[2], 16);
    const b = parseInt(m[3], 16);
    return `rgba(${r},${g},${b},${alpha})`;
}

/**
 * Initialization: sets up inputs, remembers last chosen symbol.
 */
(function init () {
    // Enable/disable buttons depending on valid amount input
    const toggle = () => {
        const valid = parseFloat($amountInp.value) > 0;
        $addBtn.disabled = $removeBtn.disabled = !valid;
    };
    $amountInp.addEventListener('input', toggle);
    toggle();

    // Restore last selected crypto symbol from localStorage
    $symbol.value = localStorage.getItem('lastSymbol') || $symbol.value;
    $symbol.addEventListener('change', () =>
        localStorage.setItem('lastSymbol', $symbol.value)
    );
})();

/**
 * App flow
 */
document.addEventListener('DOMContentLoaded', async () => {
    await service.fetchCryptoPrices().catch(console.error);
    renderUI();

    // Set button actions
    $addBtn   .addEventListener('click', () => mutate('add'));
    $removeBtn.addEventListener('click', () => mutate('remove'));
});

/**
 * Add or remove an amount from the portfolio.
 * @param {string} op - Operation name: "add" or "remove".
 */
function mutate (op) {
    const amt = parseFloat($amountInp.value);
    if (!amt) return;
    try {
        dao[op]($symbol.value, amt);
        renderUI();
    } catch (err) {
        alert(err.message);
    }
}

/*
 * UI rendering
 */
function renderUI () {
    const snapshot = service
        .getPortfolioSnapshot('USD')
        .filter(r => r.amount > 0)
        .sort((a, b) => b.value - a.value);

    const totalUSD = dao.total('USD');

    /* Build table rows */
    $body.innerHTML = '';
    snapshot.forEach(r => {
        const pct = ((r.value / totalUSD) * 100).toFixed(1);
        const rowTint = hexToRgba(COLORS[r.symbol], 0.12);
        $body.insertAdjacentHTML('beforeend', `
      <tr style='background:${rowTint}'>
        <td><span class='coin-dot' style='background:${COLORS[r.symbol]}'></span>
            <b>${r.symbol}</b></td>
        <td>${r.amount.toLocaleString()}</td>
        <td>${r.value.toLocaleString(undefined,{maximumFractionDigits:0})}$</td>
        <td>${pct}%</td>
      </tr>`);
    });

    /* Show grand total */
    $grandTotal.textContent =
        `Total in USD: ${totalUSD.toLocaleString(undefined,{maximumFractionDigits:0})}$`;
    $grandTotal.className = 'fw-bold text-start mt-4 mb-3';

    // Draw chart
    drawPie(snapshot);
}

/**
 * Pie chart – adjusts size to popup height and shows USD in tooltip
 */

/**
 * Draw a pie chart of the portfolio values.
 * @param {Array} snapshot - List of portfolio items.
 */
function drawPie (snapshot) {
    // Calculate size for chart so it fits the popup
    const base = chartBaseSize(snapshot.length);
    const topPx = $chartCvs.offsetTop;
    const padding = 16;
    const avail = window.innerHeight - topPx - padding;
    const size = Math.max(140, Math.min(base, avail));

    // Apply size to canvas
    $chartCvs.width = $chartCvs.height = size;
    $chartCvs.style.width = $chartCvs.style.height = size + 'px';

    // Prepare chart data
    const data = {
        labels: snapshot.map(r => r.symbol),
        datasets: [{
            data: snapshot.map(r => r.value),
            backgroundColor: snapshot.map(r => COLORS[r.symbol])
        }]
    };

    // Destroy old chart if it exists (to avoid overlap)
    if (chart) chart.destroy();
    // Create new pie chart
    chart = new Chart($chartCvs.getContext('2d'), {
        type: 'pie',
        data,
        options: {
            responsive: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        // Show format: 'BTC: 68,991$'
                        label: ctx => `${ctx.label}: ${ctx.parsed.toLocaleString()}$`
                    }
                }
            }
        }
    });
}
