/**
 * @file service.js
 * @description Remote price service for handling all interactions with the CEX.io API.
 * Provides methods for fetching, caching, and retrieving live cryptocurrency prices.
 */
const service = {};

// Cache that keeps the most recent price per currency pair.
/**
 * @constant {Map<string, number>} rates - A cache storing the most recent prices per currency pair.
 */
const rates = new Map();

// Which coins we track
/**
 * @constant {string[]} baseCoin - List of base currency symbols (e.g., 'BTC', 'ETH').
 */
const baseCoin   = ['BTC', 'ETH', 'LTC', 'ADA', 'XRP'];


/**
 * @constant {string[]} targetCoin - List of target currency symbols (e.g., 'USD').
 */
const targetCoin = ['USD'];

/**
 * SUPPORTED_PAIRS - List of currency pairs to fetch from the CEX.io API.
 * @constant {Array<[string, string]>} SUPPORTED_PAIRS - A list of all supported currency pairs.
 */
const SUPPORTED_PAIRS = [];
for (const base of baseCoin) {
    for (const quote of targetCoin) {
        SUPPORTED_PAIRS.push([base, quote]); // ['BTC', 'USD'] …
    }
}

/**
 * buildPairKey
 * Generates a string key for the currency pair (e.g., 'BTC/USD').
 *
 * @param {string} baseCoin - The base currency symbol (e.g., 'BTC').
 * @param {string} targetCoin - The target currency symbol (e.g., 'USD').
 * @returns {string} The pair key in the format 'BTC/USD'.
 */
function buildPairKey(baseCoin, targetCoin) {
    return baseCoin.toUpperCase() + '/' + targetCoin.toUpperCase();
}

/**
 * getStoredAmount
 * Retrieves the stored balance for a given symbol from localStorage.
 *
 * @param {string} symbol - The currency symbol (e.g., 'BTC').
 * @returns {number} The numeric balance stored for the symbol, or 0 if nothing is stored.
 */
function getStoredAmount(symbol) {
    const raw = localStorage.getItem(symbol.toUpperCase());
    return calculateBalance(raw); // from dao.js
}

/**
 * fetchCryptoPrices
 * Fetches live cryptocurrency prices from the CEX.io API and updates the in-memory cache.
 *
 * @param {Array<[string, string]>} [pairs=SUPPORTED_PAIRS] - The list of currency pairs to fetch prices for.
 * @returns {Promise<Array<Object>>} A promise that resolves to an array of objects containing price information.
 */
service.fetchCryptoPrices = async function (pairs = SUPPORTED_PAIRS) {
    const results = [];

    for (const pair of pairs) {
        const baseCoin   = pair[0];
        const targetCoin = pair[1];
        const url = `https://cex.io/api/last_price/${baseCoin}/${targetCoin}`;

        try {
            const response = await fetch(url);
            if (response.status === 404 || response.status === 400) {
                continue;
            }
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const data = await response.json();
            const price = parseFloat(data.lprice);
            if (Number.isNaN(price)) {
                throw new Error('Price missing in response');
            }

            // keep newest price in cache (for dao.total / UI)
            rates.set(buildPairKey(baseCoin, targetCoin), price);

            results.push({ pair: `${data.curr1}/${data.curr2}`, price });
        } catch (err) {
            console.error(
                '[service] fetch error for',
                baseCoin + '/' + targetCoin + ':',
                err.message
            );
            results.push({ pair: `${baseCoin}/${targetCoin}`, error: 'Fetch error' });
        }
    }

    return results;
};

/**
 * getExchangeRate
 * Retrieves the last known exchange rate for a specific currency pair.
 *
 * @param {string} from - The base currency symbol (e.g., 'BTC').
 * @param {string} to - The target currency symbol (e.g., 'USD').
 * @returns {number|null} The exchange rate, or null if not available.
 */
service.getExchangeRate = function (from, to) {
    const key = buildPairKey(from, to);
    return rates.has(key) ? rates.get(key) : null;
};

/**
 * getRateWithFallback
 * Retrieves the exchange rate for the base-to-target pair, or falls back to using USD as an intermediary.
 *
 * @param {string} baseCoin - The base currency symbol (e.g., 'BTC').
 * @param {string} targetCoin - The target currency symbol (e.g., 'USD').
 * @returns {number|null} The exchange rate, or null if unavailable.
 */
function getRateWithFallback(baseCoin, targetCoin) {
    const direct = service.getExchangeRate(baseCoin, targetCoin);
    if (typeof direct === 'number') return direct;

    // Need both USD legs
    const usdBase = service.getExchangeRate(baseCoin, 'USD');
    const usdTo   = service.getExchangeRate('USD', targetCoin);
    return typeof usdBase === 'number' && typeof usdTo === 'number'
        ? usdBase * usdTo
        : null;
}
service.getRateWithFallback = getRateWithFallback;

/**
 * getPortfolioSnapshot
 * Returns an array of objects with the symbol, amount, rate, and value of each tracked coin.
 *
 * @param {string} [targetCoin='USD'] - The target currency for valuation (default is 'USD').
 * @returns {Array<Object>} A snapshot of the portfolio with each coin's details.
 */
service.getPortfolioSnapshot = function (targetCoin = 'USD') {
    const snapshot = [];
    const seen = new Set(); // avoid duplicates if multiple quotes are added later

    for (const pair of SUPPORTED_PAIRS) {
        const symbol = pair[0];
        if (seen.has(symbol)) continue;
        seen.add(symbol);

        const amount = getStoredAmount(symbol);
        const rate   = service.getExchangeRate(symbol, targetCoin);
        const value  = typeof rate === 'number' ? amount * rate : null;
        snapshot.push({ symbol, amount, rate, value });
    }
    return snapshot;
};
