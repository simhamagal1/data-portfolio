/**
 * @file dao.js
 * @description Data Access Object for managing virtual currency holdings in localStorage.
 * Provides methods to add/remove amounts and get total value in a specified currency.
 */

// Constant variables
const dao = {}; 
const SUPPORTED_SYMBOLS = ['BTC', 'ETH', 'LTC', 'ADA', 'XRP'];


/** calculateBalance
 * Converts a stored balance string from localStorage into a number.
 * If the provided string is null or empty, this returns 0.
 *
 * @param {string|null} balanceStr - The balance string retrieved from localStorage (or null if not set).
 * @returns {number} The numeric balance value, or 0 if no balance is stored.
 */
function calculateBalance(balanceStr) {
    // If null -> return 0, else -> parse the stored string to number
    return balanceStr ? Number(balanceStr) : 0;
}


/** add
 * Updates (increments) the stored balance for the given currency symbol.
 * We keep ONE number per symbol in localStorage, e.g.  'BTC': '150.5'. Every add/remove just updates that number.
 * The balance is stored in localStorage using the currency symbol as the key.
 *

 * @param {string} symbol - The currency symbol (e.g., 'BTC').
 * @param {number} amount - The amount to add (must be a positive number).
 * @returns {number} The updated total balance for the symbol after adding the amount.
 * @throws {Error} If the currency symbol is missing or not a string.
 * @throws {Error} If the amount to add is not a positive number.
 */
dao.add = function (symbol, amount) {
    // === ERRORS HANDLING ===
    if (!symbol || typeof symbol !== 'string') {
        throw new Error('Invalid currency symbol.');
    }
    if (isNaN(amount) || amount <= 0) {
        throw new Error('Amount to add must be a positive number.');
    }

    // Validation - making sure it's all in Upper Case ('BTC', 'ETH', …)
    // balanceKey – the coin name in CAPITAL letters, e.g. 'BTC'.
    // balanceStr – the text we got from localStorage. It is null when no data yet.
    const balanceKey = symbol.toUpperCase();
    const balanceStr = localStorage.getItem(balanceKey);
    const currentBalance = calculateBalance(balanceStr);

    // Incrementally updates, save as string, return string to caller
    const newBalance = currentBalance + amount;
    localStorage.setItem(balanceKey, String(newBalance));
    return newBalance;
};


/**
* remove
* Decrements the stored balance for the given currency symbol by the specified amount.
* The balance cannot go below zero; if the removal amount exceeds the current balance, an error is thrown.
*
* @param {string} symbol - The currency symbol to decrement (e.g., 'BTC').
* @param {number} amount - The amount to remove (must be a positive number).
* @returns {number} The updated total balance for the symbol after removal.
* @throws {Error} If the currency symbol is missing or not a string.
* @throws {Error} If the amount to remove is not a positive number.
* @throws {Error} If there is no existing balance for the given symbol.
* @throws {Error} If the removal amount exceeds the current balance (overdraft).
*/
dao.remove = function (symbol, amount) {
    // === ERRORS Handling ===
    if (!symbol || typeof symbol !== 'string') {
        throw new Error('Invalid currency symbol.');
    }
    if (typeof amount !== 'number' || isNaN(amount) || amount <= 0) {
        throw new Error('Amount to remove must be a positive number.');
    }

    const balanceKey = symbol.toUpperCase();
    const balanceStr = localStorage.getItem(balanceKey);
    if (!balanceStr) {
        throw new Error('No existing balance for ' + balanceKey + '.');
    }

    const currentBalance = calculateBalance(balanceStr);
    if (amount > currentBalance) {
        throw new Error(
            'Error! wallet overdraft is not allowed. Not enough balance to remove ' +
            amount +
            ' ' +
            balanceKey +
            '.'
        );
    }

    // === SUBTRACT AMOUNT ===
    const newBalance = currentBalance - amount;
    localStorage.setItem(balanceKey, String(newBalance));

    return newBalance;
};


/**
 * total
 * Calculates the total value of all supported cryptocurrency balances in the specified target currency.
 * Iterates through each supported symbol, converts its balance to the target currency using the latest rates, and sums them up.
 *
 * @param {string} [target='USD'] - The target currency symbol to convert to (default is 'USD').
 * @returns {number} The total portfolio value in the target currency.
 */
dao.total = function total(target = 'USD') {
    let sum = 0;

    for (const symbol of SUPPORTED_SYMBOLS) {
        const balance = Number(localStorage.getItem(symbol) || 0);
        if (!balance) continue;
        // if for some reason the price is missing we continue without it
        const rate = service.getRateWithFallback(symbol, target);
        if (typeof rate !== 'number') continue;
        sum += balance * rate;
    }
    return sum;
};
